package com.example.oasisNav;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Navigation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation);
    }
}
